﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Madlib
{
    class Mandib
    {
        static void Main(string[] args)
        {
            Console.Title = "Scary Time!!!";
            Console.Read();

            Console.WriteLine("--------");
            Console.WriteLine("Madlib!");
            Console.WriteLine("-------");

           
            string TitleText = @"
           
                  
('-. .-.  ('-.                                   (`\ .-') /`  ('-.    ('-.      .-') _         .-')   .-') _              _  .-')              
( OO )  / ( OO ).-.                                `.( OO ),'_(  OO) _(  OO)    ( OO ) )       ( OO ).(  OO) )            ( \( -O )             
,--. ,--. / . --. /,--.     ,--.     .-'),-----.,--./  .--. (,------(,------,--./ ,--,'       (_)---\_/     '._ .-'),-----.,------.  ,--.   ,--.    
|  | |  | | \-.  \ |  |.-') |  |.-')( OO'  .-.  |      |  |  |  .---'|  .---|   \ |  |\       /    _ ||'--...__( OO'  .-.  |   /`. '  \  `.'  / 
|   .|  .-'-'  |  ||  | OO )|  | OO /   |  | |  |  |   |  |, |  |    |  |   |    \|  | )      \  :` `.'--.  .--/   |  | |  |  /  | |.-')     /  
|       |\| |_.'  ||  |`-' ||  |`-' \_) |  |\|  |  |.'.|  |_(|  '--.(|  '--.|  .     |/        '..`''.)  |  |  \_) |  |\|  |  |_.' (OO  \   /   
|  .-.  | |  .-.  (|  '---.(|  '---.' \ |  | |  |         |  |  .--' |  .--'|  |\    |        .-._)   \  |  |    \ |  | |  |  .  '.'|   /  /\_  
|  | |  | |  | |  ||      | |      |   `'  '-'  |   ,'.   |  |  `---.|  `---|  | \   |        \       /  |  |     `'  '-'  |  |\  \ `-./  /.__) 
`--' `--' `--' `--'`------' `------'     `-----''--'   '--'  `------'`------`--'  `--'         `-----'   `--'       `-----'`--' '--'  `--'            
           
   
             
                                                                                                                                                                ";
            Console.WriteLine(TitleText);
            Console.WriteLine("\nLet's Start");
            Console.ReadLine();


            string ad1;
            string ad2;
            string ad3;
            string an4;
            string ad5;
            string ad6;
            string fo7;
            string ve8;
            string fo9;
            string ad10;
            string ad11;
            string ad12;
            string ad13;
            string ad14;
            
            string story;

            Console.Write("\nPlease enter an Adjective that descibe night: ");
            ad1= Console.ReadLine();
            Console.Write("\nPlease enter an another Adjective for night: ");
            ad2 = Console.ReadLine();
            Console.Write("\nPlease enter a word that describe someone's sceaming: ");
            ad3 = Console.ReadLine();
            Console.Write("\nPlease enter a Animal: ");
            an4 = Console.ReadLine();
            Console.Write("\nPlease enter an animal that you don't like: ");
            ad5 = Console.ReadLine();
            Console.Write("\nPlease enter an Adjective for somethings in your bag: ");
            ad6 = Console.ReadLine();
            Console.Write("\nPlease enter any Food for halloween: ");
            fo7 = Console.ReadLine();
            Console.Write("\nPlease enter any Verb in past tense relate to outside: ");
            ve8 = Console.ReadLine();
            Console.Write("\nPlease enter any sweet Food that you like: ");
            fo9 = Console.ReadLine();
            Console.Write("\nPlease enter any thing is outside of a house: ");
            ad10 = Console.ReadLine();
            Console.Write("\nPlease enter any descriptive word for man: ");
            ad11 = Console.ReadLine();
            Console.Write("\nPlease enter any type of cloth: ");
            ad12 = Console.ReadLine();
            Console.Write("\nPlease enter a word that describe someone's face expresstion: ");
            ad13 = Console.ReadLine();
            Console.Write("\nPlease enter a body part: ");
            ad14 = Console.ReadLine();






            story = "\n       One " + ad1 + "," + ad2 + " night, no stars in sight." + "Thunder roared a " + ad3 + " hello; \nlighting flashed the trees below." + " The sound of a/an " + an4 + " could be heard in the distance." +
                      "\nIt was Halloween night. I was dressed as a " + ad5 + "." + " My bag was beside me filled with\n " + ad6 + " " + fo7 + " that I couldn't wait to eat." +
                         " As I " + ve8 + " up the driveway of the house to trick or treat, \nI wonder, what type of " + fo9 + " I will get. I hammered the " + ad10 + "." +
                           " It opens and a " + ad11 + " \nman wearing a " + ad12 + " and looks at me with " + ad13 + " face." +

                           "\n\nI screamed trick or treat, and he thrusts his " + ad14 + " against the " + ad10 + " and reacts as he sees the ghosts!";


            Console.WriteLine(story);
            string TitleText1 = @"
                       

                        _...---..._
                      ,'_         _`.
                     / / `.     ,' \ \                                                          
                    :  \___`._,'___/  :
           _        |  ..   /_\   ,,  |        _
          / \       :   \`-.___.-'/   :       /,\
         /,' \       \   `._____,'   /       /:  \                             
         |O) |        `.__..---..__.'        || ,|
      _  || .|  _   _   _  || O|  _   _   _  |' ||  _
     /,\ |'| | /.\ /;\ /,\ |' ;| /'\ /.\ /,\ | ,O| /`\
    _|_|_|___|_|_|_|_|_|_|_|_'_|_|_|_|_|_|_|_|___|_|_|_
    -=o===-.  __  -___/___\___  ,-==O==-' _ -.__ ---  _
    ___,-___-___`_|           |___.__-o__'_________-.__
     |,| | ; | ||||   HAPPY   || | | |,| |'| | ,|| |`|
     |o| | | | |'|| HALLOWEEN!|| |;| ||| |,| | |'| |;|
    _|_|_|___|_|_||___________||_|_|_|_|_|_|_|___|_|_|_
     __,--. -.__,--.  `-==O=-._  ._ ,-   -- _ --=o=-._
    ____-o_______-__-'___`_-________.___-______,-._____
     |,| |,-'| |,| |;| |o| |'-.| |,| |(| |`| |,-'| |,|        ";


            Console.WriteLine(TitleText1);
            Console.WriteLine("\n                  SPOOKY HAPPY HALLOWEEN!!");
            Console.ReadLine();

           

            

            
   
        }
    }
}
